EyeHub Merged Auto

This project was automatically merged from the following decompiled APK folders:
- ContactEye_src
- LocationEye_src
- sms-eye-4_src

What I did:
- Merged res/ with conflict files renamed with prefix <orig>_
- Merged smali/ contents into this project's smali/ preserving folder structure; if filename collisions occurred the file was renamed with prefix <orig>_
- Merged AndroidManifest.xml: combined permissions and copied application components from each manifest into one application tag.

How to build:
1. Open this folder with APKTool.apk (on your phone) and run Build.
2. Sign the resulting APK with MT Manager.
3. Install and test.

Notes and possible fixes:
- If the rebuilt APK crashes due to resources not found or class not found, you'll need to inspect the resource names and smali references. The renamed files have prefixes to avoid overwrites.

List of merged package names found:
- abyssalarmy.smseye4
- com.example.contacteye
- abyssalarmy.locationeye

Permissions included:
- abyssalarmy.locationeye.DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION
- abyssalarmy.smseye4.DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION
- android.permission.ACCESS_COARSE_LOCATION
- android.permission.ACCESS_FINE_LOCATION
- android.permission.FOREGROUND_SERVICE
- android.permission.FOREGROUND_SERVICE_LOCATION
- android.permission.INTERNET
- android.permission.READ_CALL_LOG
- android.permission.READ_CONTACTS
- android.permission.READ_SMS
- android.permission.RECEIVE_BOOT_COMPLETED
- android.permission.RECEIVE_SMS
- android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS
- com.example.contacteye.DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION
